# IT8118 – Clinic System – Azure Deployment

## Deployed URLs

| Application | URL |
|-------------|-----|
| MVC Application | https://clinic-mvc-s2g3.azurewebsites.net |
| Web API | https://clinic-api-s2g3.azurewebsites.net |
| Reporting Application | https://clinic-reports-s2g3.azurewebsites.net |


## Azure Resources

- Resource Group: rg-it8118-25b-s2g3
- SQL Server: clinicdbserver-9097.database.windows.net
- Database: ClinicDB
