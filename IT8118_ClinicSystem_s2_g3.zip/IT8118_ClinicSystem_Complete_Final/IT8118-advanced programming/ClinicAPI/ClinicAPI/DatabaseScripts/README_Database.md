# Clinic System - Data Layer Setup Guide

## Overview

This guide explains how the Clinic System's data layer is organized, how to set up the database, and how to work with the Entity Framework Core migrations.

## Project Structure

```
ClinicAPI/
??? Models/
?   ??? Domain/
?   ?   ??? Patient.cs
?   ?   ??? Doctor.cs
?   ?   ??? Specialization.cs
?   ?   ??? DoctorSpecialization.cs
?   ?   ??? Schedule.cs
?   ?   ??? Leave.cs
?   ?   ??? Appointment.cs
?   ?   ??? AppointmentStatus.cs (enum)
?   ?   ??? VisitRecord.cs
?   ?   ??? Prescription.cs
?   ?   ??? Notification.cs
?   ??? Identity/
?       ??? ApplicationUser.cs
??? Data/
?   ??? ClinicDbContext.cs
??? Services/
?   ??? DbInitializer.cs
??? Migrations/
?   ??? 20260515182004_InitialCreate.cs
?   ??? 20260515182004_InitialCreate.Designer.cs
?   ??? ClinicDbContextModelSnapshot.cs
?   ??? InitialCreate.sql
??? DatabaseScripts/
?   ??? CreateSchema.sql
?   ??? DatabaseDesign.md
?   ??? ERD_Documentation.md
?   ??? README_Database.md
??? appsettings.json (contains connection string)
??? Program.cs (DbContext registration and DbInitializer call)
??? ClinicAPI.csproj (dependencies)
```

## Database Setup

### Prerequisites

- .NET 9.0 SDK
- SQL Server LocalDB (included with Visual Studio) or SQL Server Express
- Entity Framework Core tools (installed globally): `dotnet-ef`

### Step 1: Install Global Tools (One-time)

If you haven't installed the Entity Framework Core tools globally:

```bash
dotnet tool install --global dotnet-ef --version 9.0.1
```

### Step 2: Create Database from Migrations

Navigate to the ClinicAPI project directory and run:

```bash
dotnet ef database update
```

This command will:
1. Apply any pending migrations
2. Create the `ClinicDB` database in LocalDB
3. Create all tables with relationships and indexes
4. Seed initial data (roles and specializations)

**Expected output:**
```
Build started...
Build succeeded.
Done. 1 migration completed.
```

### Step 3: Verify Database Creation

You can verify the database was created by:

1. **Using SQL Server Management Studio:**
   - Connect to `(localdb)\mssqllocaldb`
   - Look for database `ClinicDB`
   - Expand Tables to see all entity tables

2. **Using Visual Studio:**
   - View ? SQL Server Object Explorer
   - (localdb)\mssqllocaldb ? ClinicDB
   - Tables folder

### Step 4: Seed Demo Data

The database is automatically seeded with demo data when the application starts for the first time:

1. Run the application: `dotnet run`
2. The `DbInitializer.InitializeAsync()` method will:
   - Check if demo data exists
   - Create demo users (patient, 2 doctors, receptionist, manager)
   - Create demo appointments and visit records
   - Create schedules for doctors
   - All with a password of `Demo@123` (for testing only)

**Demo Credentials:**

| Username | Role | Password | Email |
|----------|------|----------|-------|
| patient@clinic.com | Patient | Demo@123 | patient@clinic.com |
| doctor1@clinic.com | Doctor | Demo@123 | doctor1@clinic.com |
| doctor2@clinic.com | Doctor | Demo@123 | doctor2@clinic.com |
| receptionist@clinic.com | Receptionist | Demo@123 | receptionist@clinic.com |
| manager@clinic.com | ClinicManager | Demo@123 | manager@clinic.com |

## Working with Migrations

### Creating a New Migration

If you modify a domain model, create a new migration:

```bash
cd ClinicAPI
dotnet ef migrations add YourMigrationName
```

For example:
```bash
dotnet ef migrations add AddDoctorPhotoUrl
```

### Applying Migrations

Apply all pending migrations to the database:

```bash
dotnet ef database update
```

### Rolling Back a Migration

Remove the last applied migration:

```bash
dotnet ef database update PreviousMigrationName
```

Or to remove the most recent migration that hasn't been applied:

```bash
dotnet ef migrations remove
```

### Viewing Migrations

List all migrations:

```bash
dotnet ef migrations list
```

### Generating SQL Scripts

Generate SQL script for manual deployment:

```bash
# Script from start to latest migration
dotnet ef migrations script -o path/to/output.sql

# Script from a specific migration to another
dotnet ef migrations script 0 InitialCreate -o path/to/create-schema.sql
```

## Entity Framework Core Configuration

### DbContext Location
`ClinicAPI/Data/ClinicDbContext.cs`

### Key Configuration Points

1. **Database Provider**: SQL Server via `UseSqlServer()`
2. **Connection String**: Defined in `appsettings.json`
   ```json
   "ConnectionStrings": {
     "DefaultConnection": "Server=(localdb)\\mssqllocaldb;Database=ClinicDB;Trusted_Connection=True;MultipleActiveResultSets=true"
   }
   ```

3. **Identity Integration**: 
   - `ClinicDbContext` extends `IdentityDbContext<ApplicationUser>`
   - Automatically includes Identity tables
   - Custom `ApplicationUser` extends `IdentityUser`

4. **Relationship Configuration**:
   - Many-to-many: Doctor ? Specialization
   - One-to-many: Doctor ? Schedule, Leave, Appointment
   - One-to-many: Patient ? Appointment
   - One-to-one: Appointment ? VisitRecord
   - All configured in `OnModelCreating()`

5. **Delete Behavior**:
   - Cascade: For ownership relationships
   - Set Null: For notifications (preserve history)

## Accessing the Database

### From Code

Inject `ClinicDbContext` in your services:

```csharp
public class AppointmentService
{
    private readonly ClinicDbContext _context;

    public AppointmentService(ClinicDbContext context)
    {
        _context = context;
    }

    public async Task<List<Appointment>> GetAppointmentsByPatient(int patientId)
    {
        return await _context.Appointments
            .Where(a => a.PatientId == patientId)
            .Include(a => a.Doctor)
            .Include(a => a.VisitRecord)
            .OrderBy(a => a.DateTimeStart)
            .ToListAsync();
    }
}
```

### From SQL Server Management Studio

Connect to `(localdb)\mssqllocaldb` and query:

```sql
-- Get all appointments for a patient
SELECT a.*, p.FullName, d.FullName as DoctorName
FROM Appointments a
JOIN Patients p ON a.PatientId = p.Id
JOIN Doctors d ON a.DoctorId = d.Id
WHERE p.Id = 1
ORDER BY a.DateTimeStart;

-- Get doctor specializations
SELECT d.FullName, s.Name
FROM Doctors d
JOIN DoctorSpecializations ds ON d.Id = ds.DoctorId
JOIN Specializations s ON ds.SpecializationId = s.Id;

-- Get visit records with prescriptions
SELECT vr.*, p.MedicationName, p.Dosage, p.Frequency
FROM VisitRecords vr
LEFT JOIN Prescriptions p ON vr.Id = p.VisitRecordId
ORDER BY vr.CreatedAt DESC;
```

## Resetting the Database

If you need to start fresh:

### Option 1: Delete and Recreate (Quickest)

```bash
dotnet ef database drop
dotnet ef database update
```

This will:
1. Delete the entire database
2. Recreate it with the current schema
3. Re-seed initial data on first app run

### Option 2: Manual Delete

1. Open SQL Server Management Studio
2. Connect to `(localdb)\mssqllocaldb`
3. Right-click `ClinicDB` ? Delete
4. Run `dotnet ef database update` to recreate

## Connection String Configurations

### Development (LocalDB)
```
Server=(localdb)\mssqllocaldb;Database=ClinicDB;Trusted_Connection=True;MultipleActiveResultSets=true
```

### Production (Azure SQL Database)
```
Server=tcp:yourserver.database.windows.net,1433;Initial Catalog=ClinicDB;Persist Security Info=False;User ID=yourusername;Password=yourpassword;MultipleActiveResultSets=False;Encrypt=True;TrustServerCertificate=False;Connection Timeout=30;
```

To use different connection strings by environment, add to `appsettings.Production.json`:

```json
{
  "ConnectionStrings": {
    "DefaultConnection": "your-production-connection-string"
  }
}
```

## Performance Tips

1. **Use Include() for Related Data**
   ```csharp
   var appointment = await _context.Appointments
       .Include(a => a.Patient)
       .Include(a => a.Doctor)
       .Include(a => a.VisitRecord)
       .FirstOrDefaultAsync(a => a.Id == id);
   ```

2. **Use AsNoTracking() for Read-Only Queries**
   ```csharp
   var appointments = await _context.Appointments
       .AsNoTracking()
       .Where(a => a.Status == AppointmentStatus.Confirmed)
       .ToListAsync();
   ```

3. **Use Select() to Project Only Needed Fields**
   ```csharp
   var appointmentDtos = await _context.Appointments
       .Select(a => new AppointmentDto
       {
           Id = a.Id,
           PatientName = a.Patient.FullName,
           DoctorName = a.Doctor.FullName,
           DateTimeStart = a.DateTimeStart
       })
       .ToListAsync();
   ```

4. **Index Frequently Filtered Columns**
   - Already indexed: Foreign keys, one-to-one relationships
   - Consider adding custom indexes for columns used in WHERE clauses

## Troubleshooting

### Issue: "No database provider has been configured"

**Cause**: `DbContext` not registered in `Program.cs`

**Solution**: Ensure `Program.cs` contains:
```csharp
builder.Services.AddDbContext<ClinicDbContext>(options =>
    options.UseSqlServer(builder.Configuration.GetConnectionString("DefaultConnection")));
```

### Issue: "Failed to resolve service for type ClinicDbContext"

**Cause**: Service not injected properly

**Solution**: Check constructor injection:
```csharp
public class MyService
{
    public MyService(ClinicDbContext context) { }
}
```

### Issue: Migration fails with "duplicate key"

**Cause**: Seeding data already exists

**Solution**: Run `dotnet ef database drop` then `dotnet ef database update`

### Issue: LocalDB not found

**Cause**: SQL Server LocalDB not installed

**Solution**: 
- Install Visual Studio with "SQL Server Express LocalDB" component
- Or install SQL Server Express separately
- Or use a different SQL Server instance and update connection string

## Database Backup and Restore

### Backup LocalDB Database

```bash
# Create backup directory
mkdir backups

# Backup database
sqlcmd -S "(localdb)\mssqllocaldb" -Q "BACKUP DATABASE ClinicDB TO DISK = 'backups\ClinicDB.bak'"
```

### Restore LocalDB Database

```bash
sqlcmd -S "(localdb)\mssqllocaldb" -Q "RESTORE DATABASE ClinicDB FROM DISK = 'backups\ClinicDB.bak'"
```

## References

- [Entity Framework Core Documentation](https://learn.microsoft.com/en-us/ef/core/)
- [ASP.NET Core Identity Documentation](https://learn.microsoft.com/en-us/aspnet/core/security/authentication/identity/)
- [Migrations and Seed Data](https://learn.microsoft.com/en-us/ef/core/managing-schemas/migrations/)
- [Relationships in EF Core](https://learn.microsoft.com/en-us/ef/core/modeling/relationships/)

## Files Summary

| File | Purpose |
|------|---------|
| `Models/Domain/*` | Entity classes for database tables |
| `Models/Identity/ApplicationUser.cs` | Extended Identity user class |
| `Data/ClinicDbContext.cs` | DbContext configuration |
| `Services/DbInitializer.cs` | Database seeding service |
| `Migrations/*` | EF Core migration files |
| `DatabaseScripts/CreateSchema.sql` | SQL script to create schema |
| `DatabaseScripts/DatabaseDesign.md` | Complete schema documentation |
| `DatabaseScripts/ERD_Documentation.md` | Entity relationship diagram |
| `appsettings.json` | Connection string configuration |
| `Program.cs` | DbContext and Identity registration |

## Next Steps

1. ? Database schema created
2. ? Demo data seeded
3. ? Create API Controllers for CRUD operations
4. ? Implement Business Logic Layer
5. ? Create Data Transfer Objects (DTOs)
6. ? Add API authentication and authorization

Refer to Task 3 for implementing the API layer.
