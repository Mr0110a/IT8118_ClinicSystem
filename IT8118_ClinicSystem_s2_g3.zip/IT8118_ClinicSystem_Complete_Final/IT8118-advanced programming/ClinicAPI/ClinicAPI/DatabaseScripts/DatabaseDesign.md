# Clinic System - Database Design Documentation

## Overview
This document describes the complete database schema and design decisions for the Clinic Management System. The database is built using Entity Framework Core 9.0 with SQL Server LocalDB.

## Database Design Justifications

### 1. AppointmentStatus Enum
**Justification**: Type safety and predictable state transitions
- **Implementation**: Stored as integer in database (0-6)
- **Values**: Requested, Confirmed, CheckedIn, InProgress, Completed, Cancelled, Missed
- **Benefit**: Prevents invalid status values and makes status transitions explicit in code rather than using strings

### 2. Separate VisitRecord from Appointment
**Justification**: Distinct business logic and lifecycle
- An appointment is created when requested, but a visit record only comes into existence after the appointment is completed
- Visit records are optional (appointments may not result in a visit if cancelled or missed)
- This separation allows:
  - Clean separation of concerns
  - Medical documentation is isolated from scheduling
  - Easy filtering of completed appointments vs. those with medical notes

### 3. Separate Schedule and Leave Tables
**Justification**: Different query patterns and update frequencies
- **Schedule**: Weekly recurring pattern (doctor works Monday-Friday 9-5)
- **Leave**: One-off time blocks (vacation, sick leave, training)
- Benefits:
  - Efficient queries for checking regular availability
  - Easy filtering for one-off absences
  - Leave records can include reason and more detailed information

### 4. Many-to-Many: Doctor ? Specialization
**Justification**: Real-world flexibility
- One doctor can have multiple specializations (e.g., General Practice + Cardiology)
- One specialization can have multiple doctors
- Implemented via junction table `DoctorSpecializations` with composite key `(DoctorId, SpecializationId)`
- Includes cascade delete to maintain referential integrity

### 5. ApplicationUser with Patient/Doctor One-to-One
**Justification**: Simplified authentication and single source of truth
- **Advantage**: Leverages ASP.NET Core Identity for:
  - Password hashing
  - Two-factor authentication
  - User role management
  - Token generation for JWT
- **Design**:
  - `ApplicationUser` extends `IdentityUser` with `CPR`, `FullName`, and optional navigation properties to `Patient` or `Doctor`
  - `Patient` has one-to-one relationship with `ApplicationUser` (cascade delete)
  - `Doctor` has one-to-one relationship with `ApplicationUser` (cascade delete)
  - `Receptionist` and `ClinicManager` are roles only (no separate tables needed)

### 6. ReferenceCode for Public Lookup
**Justification**: Security and user-friendliness
- Appointment `ReferenceCode` and Patient `ReferenceNumber` are generated as short GUID substrings
- Examples: `PAT-ABC123`, `APT-XYZ789`
- Public users can look up appointments using `PatientCPR + ReferenceCode` without exposing database IDs
- Prevents enumeration attacks (e.g., trying sequential patient IDs)

### 7. Notification with Multiple Relations
**Justification**: Flexible notification system
- Notifications can relate to:
  - A specific appointment (`RelatedAppointmentId`)
  - A specific patient (`RelatedPatientId`)
  - Or neither (general system notifications)
- Foreign keys are nullable to allow this flexibility
- Delete behavior: `SET NULL` on related entities (notifications persist even if appointment/patient is deleted)

### 8. Cascade Delete Behavior
**Applied to**:
- Doctor ? Specializations, Schedules, Leaves, Appointments (delete doctor = delete all related records)
- Patient ? Appointments, Notifications (delete patient = delete related records)
- Appointment ? VisitRecords, Notifications (delete appointment = delete medical notes and notifications)
- VisitRecord ? Prescriptions (delete visit = delete all prescriptions)

**Exception**: Notification to Appointment/Patient uses `SET NULL` to preserve notification history

## Entity Relationships

### One-to-One Relationships
- `ApplicationUser` ? `Patient` (optional)
- `ApplicationUser` ? `Doctor` (optional)
- `Appointment` ? `VisitRecord` (optional, VisitRecord is created only for completed appointments)

### One-to-Many Relationships
- `Doctor` ? `Schedule` (one doctor has many weekly schedules)
- `Doctor` ? `Leave` (one doctor can have multiple leave records)
- `Doctor` ? `Appointment` (one doctor has many appointments)
- `Patient` ? `Appointment` (one patient has many appointments)
- `Patient` ? `Notification` (one patient can receive many notifications)
- `Appointment` ? `Notification` (notifications about specific appointments)
- `VisitRecord` ? `Prescription` (one visit can have multiple prescriptions)
- `ApplicationUser` ? `Notification` (one user receives many notifications)

### Many-to-Many Relationships
- `Doctor` ? `Specialization` via `DoctorSpecialization` junction table
- Implemented with composite primary key `(DoctorId, SpecializationId)`
- Both foreign keys have cascade delete

## Database Schema

### Core Domain Tables

**Specialization**
- `Id` (PK, int)
- `Name` (nvarchar, NOT NULL)
- `Description` (nvarchar, nullable)

**Patient**
- `Id` (PK, int)
- `UserId` (FK, nvarchar ? AspNetUsers, cascade delete)
- `CPR` (nvarchar, NOT NULL) - Unique identifier for citizen
- `FullName` (nvarchar, NOT NULL)
- `Phone` (nvarchar, nullable)
- `Email` (nvarchar, nullable)
- `Address` (nvarchar, nullable)
- `DateOfBirth` (datetime2)
- `EmergencyContact` (nvarchar, nullable)
- `ReferenceNumber` (nvarchar, NOT NULL) - Public reference for lookups

**Doctor**
- `Id` (PK, int)
- `UserId` (FK, nvarchar ? AspNetUsers, cascade delete, unique)
- `LicenseNumber` (nvarchar, NOT NULL)
- `FullName` (nvarchar, NOT NULL)
- `Email` (nvarchar, nullable)
- `Phone` (nvarchar, nullable)

**DoctorSpecialization** (Junction Table)
- `DoctorId` (FK, int ? Doctor, cascade delete)
- `SpecializationId` (FK, int ? Specialization, cascade delete)
- Primary Key: `(DoctorId, SpecializationId)` composite

**Schedule**
- `Id` (PK, int)
- `DoctorId` (FK, int ? Doctor, cascade delete)
- `DayOfWeek` (int) - 0=Sunday, 1=Monday, ..., 6=Saturday
- `StartTime` (time)
- `EndTime` (time)
- `IsActive` (bit, default=1)

**Leave**
- `Id` (PK, int)
- `DoctorId` (FK, int ? Doctor, cascade delete)
- `StartDate` (datetime2)
- `EndDate` (datetime2)
- `Reason` (nvarchar, nullable)

**Appointment**
- `Id` (PK, int)
- `PatientId` (FK, int ? Patient, cascade delete)
- `DoctorId` (FK, int ? Doctor, cascade delete)
- `DateTimeStart` (datetime2)
- `DateTimeEnd` (datetime2)
- `Status` (int) - Enum: 0=Requested, 1=Confirmed, 2=CheckedIn, 3=InProgress, 4=Completed, 5=Cancelled, 6=Missed
- `ReferenceCode` (nvarchar, NOT NULL) - Public reference
- `CreatedAt` (datetime2, default=UtcNow)
- `Notes` (nvarchar, nullable)

**VisitRecord**
- `Id` (PK, int)
- `AppointmentId` (FK, int ? Appointment, cascade delete, unique)
- `Diagnosis` (nvarchar, nullable)
- `Treatment` (nvarchar, nullable)
- `DoctorNotes` (nvarchar, nullable)
- `CreatedAt` (datetime2, default=UtcNow)

**Prescription**
- `Id` (PK, int)
- `VisitRecordId` (FK, int ? VisitRecord, cascade delete)
- `MedicationName` (nvarchar, NOT NULL)
- `Dosage` (nvarchar, nullable)
- `Frequency` (nvarchar, nullable)
- `Duration` (nvarchar, nullable)
- `Instructions` (nvarchar, nullable)

**Notification**
- `Id` (PK, int)
- `UserId` (FK, nvarchar ? AspNetUsers, cascade delete)
- `Message` (nvarchar, NOT NULL)
- `IsRead` (bit, default=0)
- `CreatedAt` (datetime2, default=UtcNow)
- `RelatedAppointmentId` (FK, int ? Appointment, nullable, delete=SET NULL)
- `RelatedPatientId` (FK, int ? Patient, nullable, delete=SET NULL)

### Identity Tables (ASP.NET Core)

**AspNetUsers** (Extended ApplicationUser)
- `Id` (PK, nvarchar(450))
- `UserName` (nvarchar(256), unique)
- `NormalizedUserName` (nvarchar(256), indexed)
- `Email` (nvarchar(256), indexed)
- `NormalizedEmail` (nvarchar(256), indexed)
- `EmailConfirmed` (bit)
- `PasswordHash` (nvarchar)
- `SecurityStamp` (nvarchar)
- `PhoneNumber` (nvarchar)
- `PhoneNumberConfirmed` (bit)
- `TwoFactorEnabled` (bit)
- `LockoutEnd` (datetimeoffset)
- `LockoutEnabled` (bit)
- `AccessFailedCount` (int)
- `ConcurrencyStamp` (nvarchar)
- **Custom columns**:
  - `CPR` (nvarchar, NOT NULL)
  - `FullName` (nvarchar, NOT NULL)

**AspNetRoles**
- `Id` (PK, nvarchar(450))
- `Name` (nvarchar(256))
- `NormalizedName` (nvarchar(256), unique index)
- `ConcurrencyStamp` (nvarchar)

**AspNetUserRoles** (Junction)
- `UserId` (FK ? AspNetUsers)
- `RoleId` (FK ? AspNetRoles)
- Primary Key: `(UserId, RoleId)` composite

**AspNetUserClaims**, **AspNetRoleClaims**, **AspNetUserLogins**, **AspNetUserTokens**
- Standard Identity tables for claims, logins, and token management

## Seed Data

The database is initialized with the following seed data (created via `DbInitializer.cs` on application startup):

### Roles (4 total)
- `Patient` - Patient users
- `Doctor` - Medical staff
- `Receptionist` - Support staff
- `ClinicManager` - Administrative staff

### Specializations (5 total)
- Cardiology - Heart and vascular system
- Dermatology - Skin conditions
- Orthopedics - Bones and joints
- Neurology - Nervous system disorders
- General Practice - General medical practice

### Demo Users (all password: `Demo@123`)
1. **Patient User**: `patient@clinic.com`
   - CPR: 1234567890
   - Full Name: John Patient
   - Email: patient@clinic.com

2. **Doctor 1**: `doctor1@clinic.com`
   - CPR: 0987654321
   - Full Name: Dr. Jane Smith
   - License: LIC-001
   - Specializations: Cardiology, General Practice

3. **Doctor 2**: `doctor2@clinic.com`
   - CPR: 1111111111
   - Full Name: Dr. Ahmed Hassan
   - License: LIC-002
   - Specializations: Dermatology, General Practice

4. **Receptionist**: `receptionist@clinic.com`
   - CPR: 2222222222
   - Full Name: Sara Receptionist

5. **Manager**: `manager@clinic.com`
   - CPR: 3333333333
   - Full Name: Tom Manager

### Demo Doctor Schedules
- Both doctors work Monday-Friday (days 1-5)
- Hours: 9:00 AM - 5:00 PM
- 10 schedule records total (5 days � 2 doctors)

### Demo Appointments
1. **Future Appointment** (7 days from now)
   - Patient: John Patient
   - Doctor: Dr. Jane Smith
   - Time: 10:00 AM - 10:30 AM
   - Status: Confirmed
   - Notes: General checkup

2. **Completed Appointment** (5 days ago)
   - Patient: John Patient
   - Doctor: Dr. Ahmed Hassan
   - Time: 2:00 PM - 2:30 PM
   - Status: Completed
   - Notes: Skin consultation
   - With VisitRecord:
     - Diagnosis: Mild eczema
     - Treatment: Topical steroid cream
     - Notes: Patient responds well to topical treatment. Follow-up in 2 weeks.
     - With Prescription:
       - Medication: Hydrocortisone Cream
       - Dosage: 1%
       - Frequency: Twice daily
       - Duration: 2 weeks

## Indexes

Indexes are created for:
- All foreign keys (automatic for relationships)
- `AspNetUsers.NormalizedUserName` (unique) - Username lookups
- `AspNetUsers.NormalizedEmail` (indexed) - Email lookups
- `AspNetRoles.NormalizedName` (unique) - Role lookups
- `Doctors.UserId` (unique) - One-to-one relationship
- `Patients.UserId` (unique) - One-to-one relationship
- `Appointments.DoctorId`, `Appointments.PatientId` - Appointment queries
- `VisitRecords.AppointmentId` (unique) - Completion status queries
- `Prescriptions.VisitRecordId` - Prescription lookup
- `Notifications` indexes - User, Appointment, Patient lookups

## Migration History

Migration: `20260515182004_InitialCreate`
- Entity Framework Core Version: 9.0.1
- Created: 2025-02-15

## Implementation Notes

### Data Consistency
- All foreign keys use cascade delete where appropriate to maintain referential integrity
- Unique constraints on one-to-one relationships (`Doctors.UserId`, `Patients.UserId`, `VisitRecords.AppointmentId`)

### Performance Considerations
- Indexes on all foreign key columns enable efficient joins
- `DayOfWeek` on Schedule table allows efficient weekday filtering
- `Status` stored as integer enum for faster comparisons

### Security
- Passwords hashed via ASP.NET Core Identity (PBKDF2)
- CPR stored as plain text (in production, consider encryption at rest)
- Patient reference codes prevent ID enumeration
- Role-based access control via AspNetRoles and AspNetUserRoles

## Deployment

### Database Creation
Run the migration to create the database:
```bash
dotnet ef database update
```

### Seeding
The `DbInitializer.InitializeAsync()` method is automatically called on application startup and:
1. Applies any pending migrations
2. Checks if demo data already exists
3. Creates demo users, roles, specializations, schedules, and appointments if the database is empty

### SQL Scripts
- `CreateSchema.sql` - Contains the complete database schema with seed data for roles and specializations
- This can be run directly in SQL Server Management Studio for manual setup
