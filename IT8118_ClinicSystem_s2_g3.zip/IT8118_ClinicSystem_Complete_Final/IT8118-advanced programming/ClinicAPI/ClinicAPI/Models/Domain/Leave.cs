namespace ClinicAPI.Models.Domain
{
    public class Leave
    {
        public int Id { get; set; }
        public int DoctorId { get; set; }
        public DateTime StartDate { get; set; }
        public DateTime EndDate { get; set; }
        public string? Reason { get; set; }

        // Navigation properties
        public Doctor? Doctor { get; set; }
    }
}
