namespace ClinicAPI.Models.Domain
{
    public class DoctorSpecialization
    {
        public int DoctorId { get; set; }
        public int SpecializationId { get; set; }

        // Navigation properties
        public Doctor? Doctor { get; set; }
        public Specialization? Specialization { get; set; }
    }
}
