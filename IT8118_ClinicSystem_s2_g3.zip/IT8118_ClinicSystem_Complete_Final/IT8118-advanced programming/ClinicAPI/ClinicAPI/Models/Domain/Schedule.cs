namespace ClinicAPI.Models.Domain
{
    public class Schedule
    {
        public int Id { get; set; }
        public int DoctorId { get; set; }
        public int DayOfWeek { get; set; } // 0 = Sunday, 6 = Saturday
        public TimeSpan StartTime { get; set; }
        public TimeSpan EndTime { get; set; }
        public bool IsActive { get; set; } = true;

        // Navigation properties
        public Doctor? Doctor { get; set; }
    }
}
