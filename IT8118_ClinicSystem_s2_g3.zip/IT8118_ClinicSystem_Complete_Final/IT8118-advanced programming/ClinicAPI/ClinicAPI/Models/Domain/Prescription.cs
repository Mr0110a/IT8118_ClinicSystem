namespace ClinicAPI.Models.Domain
{
    public class Prescription
    {
        public int Id { get; set; }
        public int VisitRecordId { get; set; }
        public string MedicationName { get; set; } = string.Empty;
        public string? Dosage { get; set; }
        public string? Frequency { get; set; }
        public string? Duration { get; set; }
        public string? Instructions { get; set; }

        // Navigation properties
        public VisitRecord? VisitRecord { get; set; }
    }
}
