namespace ClinicAPI.Models.Domain
{
    public class Doctor
    {
        public int Id { get; set; }
        public string UserId { get; set; } = string.Empty;
        public string LicenseNumber { get; set; } = string.Empty;
        public string FullName { get; set; } = string.Empty;
        public string? Email { get; set; }
        public string? Phone { get; set; }

        // Navigation properties
        public Identity.ApplicationUser? User { get; set; }
        public ICollection<DoctorSpecialization> Specializations { get; set; } = new List<DoctorSpecialization>();
        public ICollection<Schedule> Schedules { get; set; } = new List<Schedule>();
        public ICollection<Leave> Leaves { get; set; } = new List<Leave>();
        public ICollection<Appointment> Appointments { get; set; } = new List<Appointment>();
    }
}
