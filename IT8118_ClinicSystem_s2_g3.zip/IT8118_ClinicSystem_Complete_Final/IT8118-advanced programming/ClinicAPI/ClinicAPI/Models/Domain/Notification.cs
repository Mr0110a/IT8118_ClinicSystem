namespace ClinicAPI.Models.Domain
{
    public class Notification
    {
        public int Id { get; set; }
        public string UserId { get; set; } = string.Empty;
        public string Message { get; set; } = string.Empty;
        public bool IsRead { get; set; } = false;
        public DateTime CreatedAt { get; set; } = DateTime.UtcNow;
        public int? RelatedAppointmentId { get; set; }
        public int? RelatedPatientId { get; set; }

        // Navigation properties
        public Identity.ApplicationUser? User { get; set; }
        public Appointment? RelatedAppointment { get; set; }
        public Patient? RelatedPatient { get; set; }
    }
}
