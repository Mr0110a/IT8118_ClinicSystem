namespace ClinicAPI.Models.Domain
{
    public class Appointment
    {
        public int Id { get; set; }
        public int PatientId { get; set; }
        public int DoctorId { get; set; }
        public DateTime DateTimeStart { get; set; }
        public DateTime DateTimeEnd { get; set; }
        public AppointmentStatus Status { get; set; } = AppointmentStatus.Requested;
        public string ReferenceCode { get; set; } = Guid.NewGuid().ToString().Substring(0, 8).ToUpper();
        public DateTime CreatedAt { get; set; } = DateTime.UtcNow;
        public string? Notes { get; set; }

        // Navigation properties
        public Patient? Patient { get; set; }
        public Doctor? Doctor { get; set; }
        public VisitRecord? VisitRecord { get; set; }
        public ICollection<Notification> Notifications { get; set; } = new List<Notification>();
    }
}
