namespace ClinicAPI.Models.Domain
{
    public enum AppointmentStatus
    {
        Requested,
        Confirmed,
        CheckedIn,
        InProgress,
        Completed,
        Cancelled,
        Missed
    }
}
