using Microsoft.AspNetCore.Identity;
using ClinicAPI.Models.Domain;

namespace ClinicAPI.Models.Identity
{
    public class ApplicationUser : IdentityUser
    {
        public string CPR { get; set; } = string.Empty;
        public string FullName { get; set; } = string.Empty;

        // Optional: one-to-one with Patient or Doctor
        public Patient? Patient { get; set; }
        public Doctor? Doctor { get; set; }
        public ICollection<Notification> Notifications { get; set; } = new List<Notification>();
    }
}
