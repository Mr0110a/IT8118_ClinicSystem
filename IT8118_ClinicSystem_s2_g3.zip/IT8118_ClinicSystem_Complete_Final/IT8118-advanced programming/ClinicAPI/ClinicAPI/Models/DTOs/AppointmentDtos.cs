using System.ComponentModel.DataAnnotations;
using ClinicAPI.Models.Domain;

namespace ClinicAPI.Models.DTOs
{
    public class BookAppointmentDto
    {
        [Required]
        public int PatientId { get; set; }

        [Required]
        public int DoctorId { get; set; }

        [Required]
        public DateTime DateTimeStart { get; set; }

        [Required]
        public DateTime DateTimeEnd { get; set; }

        public string? Notes { get; set; }
    }

    public class UpdateStatusDto
    {
        [Required]
        public AppointmentStatus NewStatus { get; set; }
    }
}
