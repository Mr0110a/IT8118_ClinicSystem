using ClinicAPI.Data;
using ClinicAPI.Models.Domain;
using ClinicAPI.Models.DTOs;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace ClinicAPI.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    [Authorize]
    public class AppointmentsController : ControllerBase
    {
        private readonly ClinicDbContext _context;

        public AppointmentsController(ClinicDbContext context)
        {
            _context = context;
        }

        // ─── GET: api/appointments/doctor/{doctorId} ──────────────────────────────

        /// <summary>Get all appointments for a specific doctor.</summary>
        [HttpGet("doctor/{doctorId}")]
        [Authorize(Roles = "Doctor,Receptionist,ClinicManager")]
        public async Task<IActionResult> GetByDoctor(int doctorId)
        {
            var doctorExists = await _context.Doctors.AnyAsync(d => d.Id == doctorId);
            if (!doctorExists)
                return NotFound(new { message = $"Doctor with ID {doctorId} not found." });

            var list = await _context.Appointments
                .Include(a => a.Patient)
                .Where(a => a.DoctorId == doctorId)
                .OrderBy(a => a.DateTimeStart)
                .Select(a => new
                {
                    a.Id,
                    PatientName = a.Patient != null ? a.Patient.FullName : "N/A",
                    StartTime   = a.DateTimeStart,
                    EndTime     = a.DateTimeEnd,
                    Status      = a.Status.ToString(),
                    a.ReferenceCode,
                    a.Notes
                })
                .ToListAsync();

            return Ok(list);
        }

        // ─── GET: api/appointments/patient/{patientId} ────────────────────────────

        /// <summary>Get all appointments for a specific patient.</summary>
        [HttpGet("patient/{patientId}")]
        [Authorize(Roles = "Patient,Doctor,Receptionist,ClinicManager")]
        public async Task<IActionResult> GetByPatient(int patientId)
        {
            var patientExists = await _context.Patients.AnyAsync(p => p.Id == patientId);
            if (!patientExists)
                return NotFound(new { message = $"Patient with ID {patientId} not found." });

            var list = await _context.Appointments
                .Include(a => a.Doctor)
                .Where(a => a.PatientId == patientId)
                .OrderByDescending(a => a.DateTimeStart)
                .Select(a => new
                {
                    a.Id,
                    DoctorName = a.Doctor != null ? a.Doctor.FullName : "N/A",
                    StartTime  = a.DateTimeStart,
                    EndTime    = a.DateTimeEnd,
                    Status     = a.Status.ToString(),
                    a.ReferenceCode,
                    a.Notes
                })
                .ToListAsync();

            return Ok(list);
        }

        // ─── POST: api/appointments ───────────────────────────────────────────────

        /// <summary>Book a new appointment. Validates doctor schedule and slot availability.</summary>
        [HttpPost]
        [Authorize(Roles = "Patient,Receptionist")]
        public async Task<IActionResult> Book([FromBody] BookAppointmentDto dto)
        {
            if (!ModelState.IsValid)
                return BadRequest(ModelState);

            // 1. Validate doctor exists and has schedules
            var doctor = await _context.Doctors
                .Include(d => d.Schedules)
                .FirstOrDefaultAsync(d => d.Id == dto.DoctorId);

            if (doctor == null)
                return NotFound(new { message = "Doctor not found." });

            // 2. Validate patient exists
            var patientExists = await _context.Patients.AnyAsync(p => p.Id == dto.PatientId);
            if (!patientExists)
                return NotFound(new { message = "Patient not found." });

            // 3. Validate appointment makes sense (end > start)
            if (dto.DateTimeEnd <= dto.DateTimeStart)
                return BadRequest(new { message = "End time must be after start time." });

            // 4. Check doctor schedule covers the requested slot
            var requestedDay = (int)dto.DateTimeStart.DayOfWeek;
            var schedule = doctor.Schedules.FirstOrDefault(s =>
                s.IsActive &&
                s.DayOfWeek == requestedDay &&
                dto.DateTimeStart.TimeOfDay >= s.StartTime &&
                dto.DateTimeEnd.TimeOfDay   <= s.EndTime);

            if (schedule == null)
                return BadRequest(new { message = "Doctor is not available at the requested time." });

            // 5. Check for overlapping confirmed/active appointments
            var overlap = await _context.Appointments.AnyAsync(a =>
                a.DoctorId == dto.DoctorId &&
                a.Status != AppointmentStatus.Cancelled &&
                a.Status != AppointmentStatus.Missed &&
                a.DateTimeStart < dto.DateTimeEnd &&
                a.DateTimeEnd   > dto.DateTimeStart);

            if (overlap)
                return Conflict(new { message = "This time slot is already booked for the doctor." });

            // 6. Create the appointment
            var appointment = new Appointment
            {
                PatientId     = dto.PatientId,
                DoctorId      = dto.DoctorId,
                DateTimeStart = dto.DateTimeStart,
                DateTimeEnd   = dto.DateTimeEnd,
                Status        = AppointmentStatus.Requested,
                ReferenceCode = GenerateReferenceCode(),
                Notes         = dto.Notes,
                CreatedAt     = DateTime.UtcNow
            };

            _context.Appointments.Add(appointment);
            await _context.SaveChangesAsync();

            return CreatedAtAction(
                nameof(GetByDoctor),
                new { doctorId = dto.DoctorId },
                new
                {
                    appointment.Id,
                    appointment.ReferenceCode,
                    StartTime = appointment.DateTimeStart,
                    EndTime   = appointment.DateTimeEnd,
                    Status    = appointment.Status.ToString()
                });
        }

        // ─── PUT: api/appointments/{id}/status ───────────────────────────────────

        /// <summary>Update the status of an appointment (enforces valid transitions).</summary>
        [HttpPut("{id}/status")]
        [Authorize(Roles = "Doctor,Receptionist")]
        public async Task<IActionResult> UpdateStatus(int id, [FromBody] UpdateStatusDto dto)
        {
            if (!ModelState.IsValid)
                return BadRequest(ModelState);

            var appointment = await _context.Appointments.FindAsync(id);
            if (appointment == null)
                return NotFound(new { message = $"Appointment with ID {id} not found." });

            if (!IsValidTransition(appointment.Status, dto.NewStatus))
                return BadRequest(new
                {
                    message = $"Invalid status transition from '{appointment.Status}' to '{dto.NewStatus}'."
                });

            appointment.Status = dto.NewStatus;
            await _context.SaveChangesAsync();

            return Ok(new
            {
                appointment.Id,
                OldStatus = appointment.Status.ToString(),
                NewStatus = dto.NewStatus.ToString()
            });
        }

        // ─── Helpers ──────────────────────────────────────────────────────────────

        private static string GenerateReferenceCode() =>
            Guid.NewGuid().ToString("N")[..8].ToUpper();

        private static bool IsValidTransition(AppointmentStatus current, AppointmentStatus next) =>
            (current, next) switch
            {
                (AppointmentStatus.Requested,  AppointmentStatus.Confirmed)  => true,
                (AppointmentStatus.Confirmed,  AppointmentStatus.CheckedIn)  => true,
                (AppointmentStatus.CheckedIn,  AppointmentStatus.InProgress) => true,
                (AppointmentStatus.InProgress, AppointmentStatus.Completed)  => true,
                (_,                            AppointmentStatus.Cancelled)  => true,
                (_,                            AppointmentStatus.Missed)     => true,
                _                                                            => false
            };
    }
}
