using System.IdentityModel.Tokens.Jwt;
using System.Security.Claims;
using System.Text;
using ClinicAPI.Models.DTOs;
using ClinicAPI.Models.Identity;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using Microsoft.IdentityModel.Tokens;

namespace ClinicAPI.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class AuthController : ControllerBase
    {
        private readonly UserManager<ApplicationUser> _userManager;
        private readonly RoleManager<IdentityRole> _roleManager;
        private readonly IConfiguration _config;

        public AuthController(
            UserManager<ApplicationUser> userManager,
            RoleManager<IdentityRole> roleManager,
            IConfiguration config)
        {
            _userManager = userManager;
            _roleManager = roleManager;
            _config = config;
        }

        /// <summary>Register a new user. Role must be one of: Patient, Doctor, Receptionist, ClinicManager.</summary>
        [HttpPost("register")]
        public async Task<IActionResult> Register([FromBody] RegisterDto dto)
        {
            if (!ModelState.IsValid)
                return BadRequest(ModelState);

            if (!await _roleManager.RoleExistsAsync(dto.Role))
                return BadRequest(new { message = $"Role '{dto.Role}' does not exist. Valid roles: Patient, Doctor, Receptionist, ClinicManager." });

            var existingUser = await _userManager.FindByEmailAsync(dto.Email);
            if (existingUser != null)
                return Conflict(new { message = "A user with this email already exists." });

            var user = new ApplicationUser
            {
                UserName    = dto.Email,
                Email       = dto.Email,
                FullName    = dto.FullName,
                CPR         = dto.CPR ?? string.Empty
            };

            var result = await _userManager.CreateAsync(user, dto.Password);
            if (!result.Succeeded)
                return BadRequest(new { errors = result.Errors.Select(e => e.Description) });

            await _userManager.AddToRoleAsync(user, dto.Role);

            return Ok(new { message = "User registered successfully.", userId = user.Id });
        }

        /// <summary>Login and receive a JWT bearer token.</summary>
        [HttpPost("login")]
        public async Task<IActionResult> Login([FromBody] LoginDto dto)
        {
            if (!ModelState.IsValid)
                return BadRequest(ModelState);

            var user = await _userManager.FindByEmailAsync(dto.Email);
            if (user == null || !await _userManager.CheckPasswordAsync(user, dto.Password))
                return Unauthorized(new { message = "Invalid email or password." });

            var roles = await _userManager.GetRolesAsync(user);
            var role  = roles.FirstOrDefault() ?? "Patient";

            var expiryMinutes = int.Parse(_config["JwtSettings:ExpiryMinutes"]!);
            var token         = GenerateJwtToken(user, role, expiryMinutes);

            return Ok(new AuthResponseDto
            {
                Token     = token,
                Role      = role,
                UserId    = user.Id,
                ExpiresAt = DateTime.UtcNow.AddMinutes(expiryMinutes)
            });
        }

        // ─── Private helpers ─────────────────────────────────────────────────────

        private string GenerateJwtToken(ApplicationUser user, string role, int expiryMinutes)
        {
            var jwtSettings = _config.GetSection("JwtSettings");
            var key         = Encoding.UTF8.GetBytes(jwtSettings["SecretKey"]!);

            var claims = new[]
            {
                new Claim(JwtRegisteredClaimNames.Sub,   user.Id),
                new Claim(JwtRegisteredClaimNames.Email, user.Email!),
                new Claim("FullName",                    user.FullName),
                new Claim(ClaimTypes.Role,               role),
                new Claim(JwtRegisteredClaimNames.Jti,   Guid.NewGuid().ToString())
            };

            var tokenDescriptor = new SecurityTokenDescriptor
            {
                Subject            = new ClaimsIdentity(claims),
                Expires            = DateTime.UtcNow.AddMinutes(expiryMinutes),
                Issuer             = jwtSettings["Issuer"],
                Audience           = jwtSettings["Audience"],
                SigningCredentials  = new SigningCredentials(
                    new SymmetricSecurityKey(key),
                    SecurityAlgorithms.HmacSha256Signature)
            };

            var handler = new JwtSecurityTokenHandler();
            var token   = handler.CreateToken(tokenDescriptor);
            return handler.WriteToken(token);
        }
    }
}
