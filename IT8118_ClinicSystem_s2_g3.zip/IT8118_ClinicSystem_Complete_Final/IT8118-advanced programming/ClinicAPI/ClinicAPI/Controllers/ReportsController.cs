using ClinicAPI.Data;
using ClinicAPI.Models.Domain;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace ClinicAPI.Controllers
{
    /// <summary>
    /// Reporting endpoints — restricted to ClinicManager role only.
    /// Consumed by the Reporting App.
    /// </summary>
    [ApiController]
    [Route("api/[controller]")]
    [Authorize(Roles = "ClinicManager")]
    public class ReportsController : ControllerBase
    {
        private readonly ClinicDbContext _context;

        public ReportsController(ClinicDbContext context)
        {
            _context = context;
        }

        // ─── GET: api/reports/cancellation-rate ──────────────────────────────────

        /// <summary>Returns cancellation and no-show rates for a given date range.</summary>
        [HttpGet("cancellation-rate")]
        public async Task<IActionResult> GetCancellationRate(
            [FromQuery] DateTime? start = null,
            [FromQuery] DateTime? end   = null)
        {
            start ??= DateTime.UtcNow.AddMonths(-1);
            end   ??= DateTime.UtcNow;

            var appointments = await _context.Appointments
                .Where(a => a.DateTimeStart >= start && a.DateTimeStart <= end)
                .ToListAsync();

            var total     = appointments.Count;
            var cancelled = appointments.Count(a => a.Status == AppointmentStatus.Cancelled);
            var missed    = appointments.Count(a => a.Status == AppointmentStatus.Missed);

            return Ok(new
            {
                Start            = start,
                End              = end,
                Total            = total,
                Cancelled        = cancelled,
                Missed           = missed,
                CancellationRate = total > 0 ? Math.Round((double)cancelled / total * 100, 2) : 0,
                NoShowRate       = total > 0 ? Math.Round((double)missed    / total * 100, 2) : 0
            });
        }

        // ─── GET: api/reports/appointment-stats ──────────────────────────────────

        /// <summary>Returns appointment count grouped by status for a given date range.</summary>
        [HttpGet("appointment-stats")]
        public async Task<IActionResult> GetAppointmentStats(
     [FromQuery] DateTime? start = null,
     [FromQuery] DateTime? end = null)
        {
            start ??= DateTime.UtcNow.AddMonths(-1);
            end ??= DateTime.UtcNow;

            var appointments = await _context.Appointments
                .Where(a => a.DateTimeStart >= start && a.DateTimeStart <= end)
                .ToListAsync();

            // Map properties directly to match AppointmentStatsDto fields exactly
            var statsDto = new
            {
                TotalAppointments = appointments.Count,
                Completed = appointments.Count(a => (int)a.Status == 4 || a.Status.ToString().Equals("Completed", StringComparison.OrdinalIgnoreCase)),
                Cancelled = appointments.Count(a => a.Status == AppointmentStatus.Cancelled),
                Missed = appointments.Count(a => a.Status == AppointmentStatus.Missed),
                Requested = appointments.Count(a => (int)a.Status == 1 || a.Status.ToString().Equals("Requested", StringComparison.OrdinalIgnoreCase))
            };

            // Return the flat object directly so the frontend can read the properties
            return Ok(statsDto);
        }

        // ─── GET: api/reports/doctor-utilisation ─────────────────────────────────

        /// <summary>Returns number of booked (non-cancelled) appointments per doctor.</summary>
        [HttpGet("doctor-utilisation")]
        public async Task<IActionResult> GetDoctorUtilisation(
            [FromQuery] DateTime? start = null,
            [FromQuery] DateTime? end = null)
        {
            start ??= DateTime.UtcNow.AddMonths(-1);
            end ??= DateTime.UtcNow;

            // 1. Fetch raw totals from database query
            var databaseData = await _context.Doctors
                .Select(d => new
                {
                    DoctorId = d.Id,
                    DoctorName = d.FullName,
                    Specialization = "General Practice", // Fallback text (update to d.Specialty if your model tracks it)
                    AvailableSlots = 10, // Base default capacity tracking
                    BookedSlots = d.Appointments.Count(a =>
                        a.DateTimeStart >= start &&
                        a.DateTimeStart <= end &&
                        a.Status != AppointmentStatus.Cancelled)
                })
                .ToListAsync();

            // 2. Compute percentages in-memory to match DoctorUtilisationDto structure perfectly
            var finalResult = databaseData.Select(d => new
            {
                d.DoctorId,
                d.DoctorName,
                d.Specialization,
                d.AvailableSlots,
                d.BookedSlots,
                UtilisationPercentage = d.AvailableSlots > 0
                    ? Math.Round((double)d.BookedSlots / d.AvailableSlots * 100, 2)
                    : 0
            })
            .OrderByDescending(d => d.BookedSlots)
            .ToList();

            // CRITICAL: Return the raw array list direct to root level so the frontend array mapping works!
            return Ok(finalResult);
        }

        // ─── GET: api/reports/daily-summary ──────────────────────────────────────

        /// <summary>Returns a day-by-day appointment count summary for a date range.</summary>
        [HttpGet("daily-summary")]
        public async Task<IActionResult> GetDailySummary(
            [FromQuery] DateTime? start = null,
            [FromQuery] DateTime? end   = null)
        {
            start ??= DateTime.UtcNow.AddDays(-7);
            end   ??= DateTime.UtcNow;

            var summary = await _context.Appointments
                .Where(a => a.DateTimeStart >= start && a.DateTimeStart <= end)
                .GroupBy(a => a.DateTimeStart.Date)
                .Select(g => new
                {
                    Date  = g.Key,
                    Count = g.Count()
                })
                .OrderBy(x => x.Date)
                .ToListAsync();

            return Ok(new { Start = start, End = end, DailySummary = summary });
        }
    }
}
