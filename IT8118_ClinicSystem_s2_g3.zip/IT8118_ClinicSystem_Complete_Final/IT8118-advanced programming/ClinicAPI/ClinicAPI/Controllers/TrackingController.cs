using ClinicAPI.Data;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace ClinicAPI.Controllers
{
    /// <summary>
    /// Public endpoint — no authentication required.
    /// Allows anyone to look up appointment status using CPR + reference code.
    /// </summary>
    [ApiController]
    [Route("api/[controller]")]
    public class TrackingController : ControllerBase
    {
        private readonly ClinicDbContext _context;

        public TrackingController(ClinicDbContext context)
        {
            _context = context;
        }

        /// <summary>
        /// Look up appointment status by patient CPR and appointment reference code.
        /// No JWT token required.
        /// </summary>
        /// <param name="cpr">Patient CPR number</param>
        /// <param name="referenceCode">8-character appointment reference code</param>
        [AllowAnonymous]
        [HttpGet("{cpr}/{referenceCode}")]
        public async Task<IActionResult> GetTracking(string cpr, string referenceCode)
        {
            // Find the patient by CPR
            var patient = await _context.Patients
                .FirstOrDefaultAsync(p => p.CPR == cpr);

            if (patient == null)
                return NotFound(new { message = "No patient found with the given CPR." });

            // Find matching appointments for this patient + reference code
            var appointments = await _context.Appointments
                .Include(a => a.Doctor)
                .Where(a => a.PatientId == patient.Id
                         && a.ReferenceCode == referenceCode)
                .OrderBy(a => a.DateTimeStart)
                .Select(a => new
                {
                    a.Id,
                    StartTime  = a.DateTimeStart,
                    EndTime    = a.DateTimeEnd,
                    DoctorName = a.Doctor != null ? a.Doctor.FullName : "N/A",
                    Status     = a.Status.ToString(),
                    a.ReferenceCode
                })
                .ToListAsync();

            if (!appointments.Any())
                return NotFound(new { message = "No appointments found for this reference code." });

            // Fetch the most recent visit record for context
            var lastVisit = await _context.VisitRecords
                .Include(v => v.Appointment)
                .Where(v => v.Appointment != null && v.Appointment.PatientId == patient.Id)
                .OrderByDescending(v => v.CreatedAt)
                .Select(v => new
                {
                    v.Diagnosis,
                    v.Treatment,
                    VisitDate = v.CreatedAt
                })
                .FirstOrDefaultAsync();

            return Ok(new
            {
                PatientName  = patient.FullName,
                Appointments = appointments,
                LastVisit    = lastVisit
            });
        }
    }
}
