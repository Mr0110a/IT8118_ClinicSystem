using ClinicAPI.Data;
using ClinicAPI.Models.Domain;
using ClinicAPI.Models.Identity;
using Microsoft.AspNetCore.Identity;
using Microsoft.EntityFrameworkCore;

namespace ClinicAPI.Services
{
    public class DbInitializer
    {
        public static async Task InitializeAsync(IServiceProvider serviceProvider)
        {
            using var context = new ClinicDbContext(serviceProvider.GetRequiredService<DbContextOptions<ClinicDbContext>>());
            using var userManager = serviceProvider.GetRequiredService<UserManager<ApplicationUser>>();
            using var roleManager = serviceProvider.GetRequiredService<RoleManager<IdentityRole>>();

            // Ensure database is created
            await context.Database.MigrateAsync();

            // Check if we already have test data
            if (context.Doctors.Any())
            {
                return; // Database already seeded
            }

            // Create demo users
            var patientUser = new ApplicationUser
            {
                UserName = "patient@clinic.com",
                Email = "patient@clinic.com",
                CPR = "1234567890",
                FullName = "John Patient"
            };

            var doctorUser1 = new ApplicationUser
            {
                UserName = "doctor1@clinic.com",
                Email = "doctor1@clinic.com",
                CPR = "0987654321",
                FullName = "Dr. Jane Smith"
            };

            var doctorUser2 = new ApplicationUser
            {
                UserName = "doctor2@clinic.com",
                Email = "doctor2@clinic.com",
                CPR = "1111111111",
                FullName = "Dr. Ahmed Hassan"
            };

            var receptionistUser = new ApplicationUser
            {
                UserName = "receptionist@clinic.com",
                Email = "receptionist@clinic.com",
                CPR = "2222222222",
                FullName = "Sara Receptionist"
            };

            var managerUser = new ApplicationUser
            {
                UserName = "manager@clinic.com",
                Email = "manager@clinic.com",
                CPR = "3333333333",
                FullName = "Tom Manager"
            };

            const string password = "Demo@123";

            // Create users
            await userManager.CreateAsync(patientUser, password);
            await userManager.CreateAsync(doctorUser1, password);
            await userManager.CreateAsync(doctorUser2, password);
            await userManager.CreateAsync(receptionistUser, password);
            await userManager.CreateAsync(managerUser, password);

            // Assign roles
            await userManager.AddToRoleAsync(patientUser, "Patient");
            await userManager.AddToRoleAsync(doctorUser1, "Doctor");
            await userManager.AddToRoleAsync(doctorUser2, "Doctor");
            await userManager.AddToRoleAsync(receptionistUser, "Receptionist");
            await userManager.AddToRoleAsync(managerUser, "ClinicManager");

            // Create doctors
            var doctor1 = new Doctor
            {
                UserId = doctorUser1.Id,
                LicenseNumber = "LIC-001",
                FullName = "Dr. Jane Smith",
                Email = "doctor1@clinic.com",
                Phone = "+45 40 40 40 40"
            };

            var doctor2 = new Doctor
            {
                UserId = doctorUser2.Id,
                LicenseNumber = "LIC-002",
                FullName = "Dr. Ahmed Hassan",
                Email = "doctor2@clinic.com",
                Phone = "+45 41 41 41 41"
            };

            context.Doctors.Add(doctor1);
            context.Doctors.Add(doctor2);

            await context.SaveChangesAsync();

            // Assign specializations to doctors
            var cardiology = context.Specializations.FirstOrDefault(s => s.Name == "Cardiology");
            var dermatology = context.Specializations.FirstOrDefault(s => s.Name == "Dermatology");
            var generalPractice = context.Specializations.FirstOrDefault(s => s.Name == "General Practice");

            if (cardiology != null)
            {
                context.DoctorSpecializations.Add(new DoctorSpecialization
                {
                    DoctorId = doctor1.Id,
                    SpecializationId = cardiology.Id
                });
            }

            if (dermatology != null)
            {
                context.DoctorSpecializations.Add(new DoctorSpecialization
                {
                    DoctorId = doctor2.Id,
                    SpecializationId = dermatology.Id
                });
            }

            if (generalPractice != null)
            {
                context.DoctorSpecializations.Add(new DoctorSpecialization
                {
                    DoctorId = doctor1.Id,
                    SpecializationId = generalPractice.Id
                });
                context.DoctorSpecializations.Add(new DoctorSpecialization
                {
                    DoctorId = doctor2.Id,
                    SpecializationId = generalPractice.Id
                });
            }

            // Create sample schedules (Monday-Friday, 9 AM - 5 PM)
            for (int dayOfWeek = 1; dayOfWeek <= 5; dayOfWeek++) // 1 = Monday, 5 = Friday
            {
                context.Schedules.Add(new Schedule
                {
                    DoctorId = doctor1.Id,
                    DayOfWeek = dayOfWeek,
                    StartTime = new TimeSpan(9, 0, 0),
                    EndTime = new TimeSpan(17, 0, 0),
                    IsActive = true
                });

                context.Schedules.Add(new Schedule
                {
                    DoctorId = doctor2.Id,
                    DayOfWeek = dayOfWeek,
                    StartTime = new TimeSpan(9, 0, 0),
                    EndTime = new TimeSpan(17, 0, 0),
                    IsActive = true
                });
            }

            // Create patient
            var patient = new Patient
            {
                UserId = patientUser.Id,
                CPR = "1234567890",
                FullName = "John Patient",
                Phone = "+45 30 30 30 30",
                Email = "patient@clinic.com",
                Address = "123 Main Street, Copenhagen",
                DateOfBirth = new DateTime(1980, 5, 15),
                EmergencyContact = "Jane Doe +45 31 31 31 31",
                ReferenceNumber = $"PAT-{Guid.NewGuid().ToString().Substring(0, 6).ToUpper()}"
            };

            context.Patients.Add(patient);

            await context.SaveChangesAsync();

            // Create sample appointments
            var futureDate = DateTime.UtcNow.AddDays(7);
            var appointment1 = new Appointment
            {
                PatientId = patient.Id,
                DoctorId = doctor1.Id,
                DateTimeStart = new DateTime(futureDate.Year, futureDate.Month, futureDate.Day, 10, 0, 0),
                DateTimeEnd = new DateTime(futureDate.Year, futureDate.Month, futureDate.Day, 10, 30, 0),
                Status = AppointmentStatus.Confirmed,
                ReferenceCode = Guid.NewGuid().ToString().Substring(0, 8).ToUpper(),
                Notes = "General checkup",
                CreatedAt = DateTime.UtcNow
            };

            context.Appointments.Add(appointment1);

            await context.SaveChangesAsync();

            // Create a sample visit record for a completed appointment
            var completedDate = DateTime.UtcNow.AddDays(-5);
            var completedAppointment = new Appointment
            {
                PatientId = patient.Id,
                DoctorId = doctor2.Id,
                DateTimeStart = new DateTime(completedDate.Year, completedDate.Month, completedDate.Day, 14, 0, 0),
                DateTimeEnd = new DateTime(completedDate.Year, completedDate.Month, completedDate.Day, 14, 30, 0),
                Status = AppointmentStatus.Completed,
                ReferenceCode = Guid.NewGuid().ToString().Substring(0, 8).ToUpper(),
                Notes = "Skin consultation",
                CreatedAt = completedDate
            };

            context.Appointments.Add(completedAppointment);
            await context.SaveChangesAsync();

            var visitRecord = new VisitRecord
            {
                AppointmentId = completedAppointment.Id,
                Diagnosis = "Mild eczema",
                Treatment = "Topical steroid cream",
                DoctorNotes = "Patient responds well to topical treatment. Follow-up in 2 weeks.",
                CreatedAt = completedDate
            };

            context.VisitRecords.Add(visitRecord);

            var prescription = new Prescription
            {
                VisitRecordId = visitRecord.Id,
                MedicationName = "Hydrocortisone Cream",
                Dosage = "1%",
                Frequency = "Twice daily",
                Duration = "2 weeks",
                Instructions = "Apply thin layer to affected areas. Avoid eyes."
            };

            context.Prescriptions.Add(prescription);

            await context.SaveChangesAsync();
        }
    }
}
