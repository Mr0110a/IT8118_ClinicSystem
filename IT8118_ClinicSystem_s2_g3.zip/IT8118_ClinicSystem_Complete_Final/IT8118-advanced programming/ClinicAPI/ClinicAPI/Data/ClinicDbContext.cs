using Microsoft.AspNetCore.Identity.EntityFrameworkCore;
using Microsoft.AspNetCore.Identity;
using Microsoft.EntityFrameworkCore;
using ClinicAPI.Models.Domain;
using ClinicAPI.Models.Identity;

namespace ClinicAPI.Data
{
    public class ClinicDbContext : IdentityDbContext<ApplicationUser>
    {
        public ClinicDbContext(DbContextOptions<ClinicDbContext> options) : base(options) { }

        public DbSet<Patient> Patients { get; set; }
        public DbSet<Doctor> Doctors { get; set; }
        public DbSet<Specialization> Specializations { get; set; }
        public DbSet<DoctorSpecialization> DoctorSpecializations { get; set; }
        public DbSet<Schedule> Schedules { get; set; }
        public DbSet<Leave> Leaves { get; set; }
        public DbSet<Appointment> Appointments { get; set; }
        public DbSet<VisitRecord> VisitRecords { get; set; }
        public DbSet<Prescription> Prescriptions { get; set; }
        public DbSet<Notification> Notifications { get; set; }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            base.OnModelCreating(modelBuilder);

            // Many-to-many: Doctor <-> Specialization
            modelBuilder.Entity<DoctorSpecialization>()
                .HasKey(ds => new { ds.DoctorId, ds.SpecializationId });

            modelBuilder.Entity<DoctorSpecialization>()
                .HasOne(ds => ds.Doctor)
                .WithMany(d => d.Specializations)
                .HasForeignKey(ds => ds.DoctorId)
                .OnDelete(DeleteBehavior.Cascade);

            modelBuilder.Entity<DoctorSpecialization>()
                .HasOne(ds => ds.Specialization)
                .WithMany(s => s.DoctorSpecializations)
                .HasForeignKey(ds => ds.SpecializationId)
                .OnDelete(DeleteBehavior.Cascade);

            // One-to-many: Doctor -> Schedule
            modelBuilder.Entity<Schedule>()
                .HasOne(s => s.Doctor)
                .WithMany(d => d.Schedules)
                .HasForeignKey(s => s.DoctorId)
                .OnDelete(DeleteBehavior.Cascade);

            // One-to-many: Doctor -> Leave
            modelBuilder.Entity<Leave>()
                .HasOne(l => l.Doctor)
                .WithMany(d => d.Leaves)
                .HasForeignKey(l => l.DoctorId)
                .OnDelete(DeleteBehavior.Cascade);

            // One-to-many: Patient -> Appointment
            modelBuilder.Entity<Appointment>()
                .HasOne(a => a.Patient)
                .WithMany(p => p.Appointments)
                .HasForeignKey(a => a.PatientId)
                .OnDelete(DeleteBehavior.Cascade);

            // One-to-many: Doctor -> Appointment
            // NOTE: Restrict (not Cascade) to avoid multiple cascade paths via
            // ApplicationUser → Patient → Appointment and ApplicationUser →
            // Doctor → Appointment. The DoctorsController prevents deleting a
            // doctor with active appointments.
            modelBuilder.Entity<Appointment>()
                .HasOne(a => a.Doctor)
                .WithMany(d => d.Appointments)
                .HasForeignKey(a => a.DoctorId)
                .OnDelete(DeleteBehavior.Restrict);

            // One-to-one: Appointment -> VisitRecord
            modelBuilder.Entity<VisitRecord>()
                .HasOne(v => v.Appointment)
                .WithOne(a => a.VisitRecord)
                .HasForeignKey<VisitRecord>(v => v.AppointmentId)
                .OnDelete(DeleteBehavior.Cascade);

            // One-to-many: VisitRecord -> Prescription
            modelBuilder.Entity<Prescription>()
                .HasOne(p => p.VisitRecord)
                .WithMany(v => v.Prescriptions)
                .HasForeignKey(p => p.VisitRecordId)
                .OnDelete(DeleteBehavior.Cascade);

            // One-to-many: Appointment -> Notification
            modelBuilder.Entity<Notification>()
                .HasOne(n => n.RelatedAppointment)
                .WithMany(a => a.Notifications)
                .HasForeignKey(n => n.RelatedAppointmentId)
                .OnDelete(DeleteBehavior.SetNull);

            // One-to-many: Patient -> Notification (RelatedPatient)
            // NOTE: NoAction (not SetNull) to avoid multiple cascade paths
            // through Patient → Appointment → Notification (RelatedAppointment)
            // and Patient → Notification (RelatedPatient).
            modelBuilder.Entity<Notification>()
                .HasOne(n => n.RelatedPatient)
                .WithMany(p => p.Notifications)
                .HasForeignKey(n => n.RelatedPatientId)
                .OnDelete(DeleteBehavior.NoAction);

            // One-to-many: ApplicationUser -> Notification
            // NOTE: Restrict (not Cascade) to avoid multiple cascade paths
            // through Patient/Doctor → ApplicationUser → Notification.
            // Notifications will be removed manually before deleting a user.
            modelBuilder.Entity<Notification>()
                .HasOne(n => n.User)
                .WithMany(u => u.Notifications)
                .HasForeignKey(n => n.UserId)
                .OnDelete(DeleteBehavior.Restrict);

            // One-to-one: ApplicationUser -> Patient
            modelBuilder.Entity<Patient>()
                .HasOne(p => p.User)
                .WithOne(u => u.Patient)
                .HasForeignKey<Patient>(p => p.UserId)
                .OnDelete(DeleteBehavior.Cascade);

            // One-to-one: ApplicationUser -> Doctor
            modelBuilder.Entity<Doctor>()
                .HasOne(d => d.User)
                .WithOne(u => u.Doctor)
                .HasForeignKey<Doctor>(d => d.UserId)
                .OnDelete(DeleteBehavior.Cascade);

            // Seed roles
            modelBuilder.Entity<IdentityRole>().HasData(
                new IdentityRole { Id = "1", Name = "Patient", NormalizedName = "PATIENT" },
                new IdentityRole { Id = "2", Name = "Doctor", NormalizedName = "DOCTOR" },
                new IdentityRole { Id = "3", Name = "Receptionist", NormalizedName = "RECEPTIONIST" },
                new IdentityRole { Id = "4", Name = "ClinicManager", NormalizedName = "CLINICMANAGER" }
            );

            // Seed specializations
            modelBuilder.Entity<Specialization>().HasData(
                new Specialization { Id = 1, Name = "Cardiology", Description = "Heart and vascular system" },
                new Specialization { Id = 2, Name = "Dermatology", Description = "Skin conditions" },
                new Specialization { Id = 3, Name = "Orthopedics", Description = "Bones and joints" },
                new Specialization { Id = 4, Name = "Neurology", Description = "Nervous system disorders" },
                new Specialization { Id = 5, Name = "General Practice", Description = "General medical practice" }
            );
        }
    }
}
