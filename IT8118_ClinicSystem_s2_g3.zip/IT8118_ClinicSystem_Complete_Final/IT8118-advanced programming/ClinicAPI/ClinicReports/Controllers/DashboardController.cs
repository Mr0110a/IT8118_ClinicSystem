﻿using ClinicReports.Models;
using Microsoft.AspNetCore.Mvc;
using System.Net.Http.Json;
using System.Text.Json;

namespace ClinicReports.Controllers
{
    public class DashboardController : Controller
    {
        private readonly IHttpClientFactory _clientFactory;

        public DashboardController(IHttpClientFactory clientFactory)
        {
            _clientFactory = clientFactory;
        }

        public async Task<IActionResult> Index()
        {
            // Create a specialized secure client configured to auto-attach our JWT tokens
            var client = _clientFactory.CreateClient("SecureClinicApiClient");

            try
            {
                // Fetch Stats (Works perfectly with the direct flat object from the updated backend)
                var stats = await client.GetFromJsonAsync<AppointmentStatsDto>("api/reports/appointment-stats");

                // Fetch Doctor Utilisation (Since backend returns a flat array directly now, no JsonNode wrapper is needed!)
                var utilisation = await client.GetFromJsonAsync<List<DoctorUtilisationDto>>("api/reports/doctor-utilisation")
                                  ?? new List<DoctorUtilisationDto>();

                // Fetch Cancellation Rate (Fetch the object summary single item and cleanly wrap it in a list container)
                var cancellationsDto = await client.GetFromJsonAsync<CancellationRateDto>("api/reports/cancellation-rate");
                var cancellations = new List<CancellationRateDto> { cancellationsDto };

                // Bind datasets to view containers
                ViewBag.UtilisationData = utilisation;
                ViewBag.CancellationData = cancellations;

                return View(stats);
            }
            catch (HttpRequestException)
            {
                // If the API endpoint throws an authorization challenge, bounce them to login
                return RedirectToAction("Login", "Account");
            }
        }
    }
}